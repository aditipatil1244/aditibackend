const {
  getTask,
  getTasks,
  postTask,
  putTask,
  deleteTask,
} = require("../controllers/controller");

const router = require("express").Router();

router.get("/tasks/:id", getTask);
router.get("/tasks", getTasks);
router.post("/tasks", postTask);
router.put("/tasks/:id", putTask);
router.delete("/tasks/:id", deleteTask);

module.exports = router;
