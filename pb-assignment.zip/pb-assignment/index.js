const express = require("express");
const app = express();
const port = 5500;
const router = require("./routes/routes");

app.use(express.json());

app.use("/", router);

//error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: "Internal Server Error" });
});

app.listen(port, () => {
  console.log(`Task Manager API listening at http://localhost:${port}`);
});
