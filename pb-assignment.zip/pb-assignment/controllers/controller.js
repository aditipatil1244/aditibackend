const db = [];
let idCounter = 1;

const isValid = (item) => {
  return item && item.title && item.description;
};

async function getTask(req, res, next) {
  try {
    const task = db.find((i) => i.id === parseInt(req.params.id));
    if (!task) {
      return res.status(404).json({ error: "Not Found" });
    }
    res.status(200).json(task);
  } catch (error) {
    next(error);
  }
}

async function getTasks(req, res, next) {
  try {
    res.status(200).json(db);
  } catch (error) {
    next(error);
  }
}

async function postTask(req, res, next) {
  try {
    const newTask = {
      id: idCounter++,
      title: req.body.title,
      description: req.body.description,
    };

    if (!isValid(newTask)) {
      return res.status(400).json({ error: "Invalid Input" });
    }

    db.push(newTask);
    res.status(201).json(newTask);
  } catch (error) {
    next(error);
  }
}

async function putTask(req, res, next) {
  try {
    const task = db.find((i) => i.id === parseInt(req.params.id));
    if (!task) {
      return res.status(404).json({ error: "Not Found" });
    }

    if (!isValid(req.body)) {
      return res.status(400).json({ error: "Invalid Input" });
    }

    task.title = req.body.title;
    task.description = req.body.description;
    res.status(200).json(task);
  } catch (error) {
    next(error);
  }
}

async function deleteTask(req, res, next) {
  try {
    const index = db.findIndex((i) => i.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ error: "Not Found" });
    }

    db.splice(index, 1);
    res.status(204).send();
  } catch (error) {
    next(error);
  }
}

module.exports = {
  deleteTask,
  getTask,
  getTasks,
  postTask,
  putTask,
};
